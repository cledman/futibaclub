const express = require('express')
const app = express()

app.use(express.static('public'))//aqui é um middlewaare, onde tudo que for estático, apontará para public
app.set('view engine', 'ejs')

app.get('/', (req,res) =>{
    res.render('home')
})

app.listen(3000, err => {   
    console.log('Futiba Club server is running')
})
